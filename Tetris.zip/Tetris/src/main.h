#pragma once
void clearBuffer();
