#include "GameGrid.h"
#include <LedControl.h> 

Field::Field() : _buzzer(10) 
{
    memset(_grid, 0, sizeof(_grid));
}

void Field::checkForFullRows()
{
    for (int y = 0; y < HEIGHT; y++)
    {
        if (_grid[y] == 0xFF) 
        { 
            for (int j = y; j > 0; j--)
            {
                _grid[j] = _grid[j - 1];
            }
            _grid[0] = 0; 
            
            _buzzer.sfxLineClear(); 
        }
    }
}

void Field::addPieceToField(const Block &block)
{
    for (int i = 0; i < PIXELS_PER_FIGURE; i++)
    {
        int xx = block.getX() + block.getShape()[i][0];
        int yy = block.getY() + block.getShape()[i][1];

        if (yy >= 0 && yy < HEIGHT && xx >= 0 && xx < WIDTH)
        {
            bitSet(_grid[yy], xx);
        }
    }
}

bool Field::checkCollision(const Block &block, int newX, int newY) const
{
    for (int i = 0; i < PIXELS_PER_FIGURE; i++)
    {
        int fieldX = newX + block.getShape()[i][0];
        int fieldY = newY + block.getShape()[i][1];

        if (fieldX < 0 || fieldX >= WIDTH) return true;

        if (fieldY >= HEIGHT) return true;

        if (fieldY >= 0) 
        {
            if (bitRead(_grid[fieldY], fieldX)) return true;
        }
    }
    return false;
}

bool Field::isCollisionAtTop(const Block &block, int newX, int newY) const
{
    for (int i = 0; i < PIXELS_PER_FIGURE; i++)
    {
        int fieldX = newX + block.getShape()[i][0];
        int fieldY = newY + block.getShape()[i][1];

        if (fieldY < 0) return true;
        if (fieldY >= 0 && fieldY < 2 && bitRead(_grid[fieldY], fieldX)) return true;
    }
    return false;
}

void Field::placeBlock(Block &block)
{
    addPieceToField(block);
    checkForFullRows();
}

bool Field::dropPiece(Block &block)
{
    if (!checkCollision(block, block.getX(), block.getY() + 1))
    {
        block.setY(block.getY() + 1);
        return false;
    }
    else
    {
        bool hitTop = (block.getY() <= 0);
        
        if (!hitTop) {
            for (int i = 0; i < PIXELS_PER_FIGURE; i++) {
                if (block.getY() + block.getShape()[i][1] < 0) {
                    hitTop = true;
                    break;
                }
            }
        }

        if (hitTop)
        {
            return true; 
        }
        else
        {
            placeBlock(block);
            block.spawnBlock(*this); 
            _buzzer.sfxHardDrop(); 
            return false;
        }
    }
}

void Field::writeBuffer(const Block &block, LedControl &lc) 
{
    uint8_t buf[MODULES][8] = {0}; 

    for (int y = 0; y < HEIGHT; y++)
    {
        uint8_t rowData = _grid[y];
        if (!rowData) continue;

        int mod = MODULES - 1 - (y / 8);
        int bitPos = 7 - (y % 8);

        for (int col = 0; col < WIDTH; col++)
        {
            if (bitRead(rowData, col))
            {
                bitSet(buf[mod][col], bitPos);
            }
        }
    }

    for (int i = 0; i < PIXELS_PER_FIGURE; i++)
    {
        int fieldX = block.getX() + block.getShape()[i][0];
        int fieldY = block.getY() + block.getShape()[i][1];

        if (fieldY < 0 || fieldY >= HEIGHT || fieldX < 0 || fieldX >= WIDTH)
            continue;

        int mod = MODULES - 1 - (fieldY / 8);
        int bitPos = 7 - (fieldY % 8);

        bitSet(buf[mod][fieldX], bitPos);
    }

    for (int m = 0; m < MODULES; m++)
    {
        for (int row = 0; row < 8; row++)
        {
            lc.setRow(m, row, buf[m][row]);
        }
    }
}