#include <Arduino.h>
#include "GameLogic.h"

Game game;

void setup()
{
    game.init();
}

void loop()
{
    game.update();
}