#include "Tetramino.h"
#include "GameGrid.h"

void Block::chose(int r, int startX)
{
    _x = startX;
    _y = 0;
    _rotation = 0;

    switch (r)
    {
        case 0: _shape = I_SHAPE[0]; _type = Type::I; break;
        case 1: _shape = O_SHAPE[0]; _type = Type::O; break;
        case 2: _shape = T_SHAPE[0]; _type = Type::T; break;
        case 3: _shape = L_SHAPE[0]; _type = Type::L; break;
        case 4: _shape = J_SHAPE[0]; _type = Type::J; break;
        case 5: _shape = S_SHAPE[0]; _type = Type::S; break;
        case 6: _shape = Z_SHAPE[0]; _type = Type::Z; break;
        default: _shape = nullptr;   _type = Type::None; break;
    }
}

void Block::spawnBlock(Field &field)
{
    const int figureHalfSize = 2;
    int centerX = (field.getWidth() / 2) - figureHalfSize; 
    
    const int figuresAmount = 7;
    int r = random(figuresAmount);
    chose(r, centerX);
}

void Block::rotatePiece(Field &field)
{
    int rotationLimit;

    switch (_type) {
        case Type::I: case Type::S: case Type::Z: rotationLimit = 2; break;
        case Type::O: rotationLimit = 1; break;
        default:      rotationLimit = 4; break;
    }

    int nextRotation = (_rotation + 1) % rotationLimit;

    const int (*nextShape)[2] = nullptr;
    
    switch (_type) {
        case Type::I: nextShape = I_SHAPE[nextRotation]; break;
        case Type::O: nextShape = O_SHAPE[0]; break;
        case Type::T: nextShape = T_SHAPE[nextRotation]; break;
        case Type::L: nextShape = L_SHAPE[nextRotation]; break;
        case Type::J: nextShape = J_SHAPE[nextRotation]; break;
        case Type::S: nextShape = S_SHAPE[nextRotation]; break;
        case Type::Z: nextShape = Z_SHAPE[nextRotation]; break;
        default: return;
    }

    Block backup = *this;

    _rotation = nextRotation;
    _shape = nextShape;

    if (field.checkCollision(*this, _x, _y)) 
    {
        *this = backup;
    }
}

void Block::movePiece(int dir, Field &field)
{
    int newX = _x + dir;
    
    if (!field.checkCollision(*this, newX, _y))
    {
        _x = newX;
    }
}