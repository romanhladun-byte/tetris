#pragma once
#include <Arduino.h>
#include <LedControl.h>
#include "Display.h"
#include "DebouncingButton.h"
#include "GameGrid.h"
#include "Tetramino.h"
#include "Sounds.h"

// Напрямки руху для читабельності
enum Direction {
    DIR_RIGHT = -1,
    DIR_LEFT = 1
};

class Game
{
private:
    // --- Hardware Constants ---
    static constexpr int DIN_PIN = 6;
    static constexpr int CLK_PIN = 5;
    static constexpr int CS_PIN = 3;
    static constexpr int SW_PIN = 7;
    static constexpr int VRX_PIN = A0;
    static constexpr int VRY_PIN = A1;
    static constexpr int BUZZER_PIN = 10; 

    // --- Game Constants ---
    static constexpr int MODULES = 4;
    static constexpr int SCREEN_W = 8;

    // --- Timing (ms) ---
    static constexpr unsigned long moveInterval = 180;
    static constexpr unsigned long refreshInterval = 30;
    unsigned long dropInterval = 500;
    unsigned long lastDrop = 0;
    unsigned long lastMove = 0;
    unsigned long lastRefresh = 0;

    // --- Objects ---
    LedControl _lc;
    Display _display;
    DebButton _btnRotate;
    Field _gameField;
    Block _currentBlock;
    Buzzer _buzzer;

public:
    Game() : 
        _lc(DIN_PIN, CLK_PIN, CS_PIN, MODULES),
        _display(_lc, MODULES, SCREEN_W),
        _btnRotate(SW_PIN),
        _gameField(),    
        _currentBlock(), 
        _buzzer(BUZZER_PIN)
    {}

    void init();
    void resetGame();
    void update();
    void refreshScreen();
    void handleInput();
    void handleGravity();

    LedControl& getLedControl() { return _lc; }
    Display& getDisplay() { return _display; }
};

void Game::init()
{
    Serial.begin(9600);
    _btnRotate.attach(); 

    _display.setup(); 
    for (int i = 0; i < MODULES; i++)
    {
        _lc.setIntensity(i, 3);
        _lc.clearDisplay(i);
    }

    randomSeed(analogRead(A5));

    _display.PrintText("PLAY"); 
    
    _btnRotate.waitForButtonPress(); 
    
    _display.clearDisplay();
    resetGame(); 
}

void Game::resetGame()
{
    memset(_gameField.getGrid(), 0, _gameField.getHeight());
    
    _display.clearDisplay();
    _currentBlock.spawnBlock(_gameField);
    
    _buzzer.sfxGameOver(); 
    
    lastDrop = millis();
    lastRefresh = millis();
}

void Game::refreshScreen()
{
    unsigned long now = millis();
    if (now - lastRefresh >= refreshInterval)
    {
        _gameField.writeBuffer(_currentBlock, _lc);
        lastRefresh = now;
    }
}

void Game::handleInput()
{
    unsigned long now = millis();
    int ax = analogRead(VRX_PIN);
    int ay = analogRead(VRY_PIN);

    if (now - lastMove > moveInterval)
    {
        if (ax < 400) 
        {
            _currentBlock.movePiece(DIR_RIGHT, _gameField);
            _buzzer.sfxMove();
            lastMove = now;
        }
        else if (ax > 600) 
        {
            _currentBlock.movePiece(DIR_LEFT, _gameField);
            _buzzer.sfxMove();
            lastMove = now;
        }
    }

    if (_btnRotate.isClicked()) 
    {
        _currentBlock.rotatePiece(_gameField);
        _buzzer.sfxRotate();
    }

    dropInterval = (ay > 600) ? 50 : 500;
}

void Game::handleGravity()
{
    unsigned long now = millis();
    if (now - lastDrop > dropInterval)
    {
        if (_gameField.dropPiece(_currentBlock))
        {
            _display.gameOverAnimation();
            delay(500);
            
            _display.PrintText("PLAY");
            _btnRotate.waitForButtonPress(); 
            
            resetGame();
            return;
        }
        
        lastDrop = now;
    }
}

void Game::update()
{
    handleInput();
    handleGravity();
    refreshScreen();
}