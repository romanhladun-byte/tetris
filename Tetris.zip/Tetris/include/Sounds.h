#pragma once
#include <Arduino.h>

class Buzzer
{
private:
    const int buzzerPin;

public:
    Buzzer(int pin) : buzzerPin(pin) {}

    void sfxMove()
    {
        tone(buzzerPin, 1800, 5); 
    }

    void sfxRotate()
    {
        tone(buzzerPin, 900, 10);
        delay(15);
        tone(buzzerPin, 1300, 10);
    }

    void sfxHardDrop()
    {
        for (int f = 400; f > 100; f -= 50)
        {
            tone(buzzerPin, f, 10);
            delay(5);
        }
        tone(buzzerPin, 80, 40);
        delay(40);
        noTone(buzzerPin);
    }

    void sfxLineClear()
    {
        int notes[] = {1000, 1200, 1500, 1800};
        for (int i = 0; i < 4; i++)
        {
            tone(buzzerPin, notes[i], 30);
            delay(35);
        }
        noTone(buzzerPin);
    }

    void sfxTetris()
    {
        for (int f = 800; f < 2000; f += 150)
        {
            tone(buzzerPin, f, 20);
            delay(20);
        }
        tone(buzzerPin, 1500, 100);
        delay(120);
        tone(buzzerPin, 2200, 200);
        delay(200);
        noTone(buzzerPin);
    }

    void sfxGameOver()
    {
        for (int i = 0; i < 20; i++)
        {
            int freq = 600 - (i * 25);
            tone(buzzerPin, freq + random(-20, 20), 40);
            delay(45);
        }
        tone(buzzerPin, 60, 800);
        delay(800);
        noTone(buzzerPin);
    }

    void clearLines() {}
};