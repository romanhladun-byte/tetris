#pragma once

#include <Arduino.h>
#include <LedControl.h>
#include <avr/pgmspace.h>

const uint8_t LETTER_G[8] PROGMEM = {0x3C, 0x42, 0x40, 0x4E, 0x42, 0x42, 0x3C, 0x00};
const uint8_t LETTER_A[8] PROGMEM = {0x18, 0x24, 0x42, 0x7E, 0x42, 0x42, 0x42, 0x00};
const uint8_t LETTER_M[8] PROGMEM = {0x42, 0x66, 0x5A, 0x5A, 0x42, 0x42, 0x42, 0x00};
const uint8_t LETTER_E[8] PROGMEM = {0x7E, 0x40, 0x5C, 0x40, 0x40, 0x40, 0x7E, 0x00};
const uint8_t LETTER_O[8] PROGMEM = {0x3C, 0x42, 0x42, 0x42, 0x42, 0x42, 0x3C, 0x00};
const uint8_t LETTER_V[8] PROGMEM = {0x42, 0x42, 0x42, 0x42, 0x42, 0x24, 0x18, 0x00};
const uint8_t LETTER_R[8] PROGMEM = {0x7C, 0x42, 0x42, 0x7C, 0x48, 0x44, 0x42, 0x00};
const uint8_t LETTER_P[8] PROGMEM = {0x7C, 0x42, 0x42, 0x7C, 0x40, 0x40, 0x40, 0x00};
const uint8_t LETTER_L[8] PROGMEM = {0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x7E, 0x00};
const uint8_t LETTER_Y[8] PROGMEM = {0x42, 0x42, 0x24, 0x18, 0x18, 0x18, 0x18, 0x00};
const uint8_t LETTER_EMPTY[8] PROGMEM = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

class Display
{
private:
    LedControl &lc;
    int numModules;
    static constexpr int MATRIX_SIZE = 8;

    const uint64_t images[12] PROGMEM = {
        0x00006192920c0000, 0x000041a2120c0000, 0x000001c23c000000,
        0x0000003ec1000000, 0x0000182443800000, 0x0000182424c30000,
        0x00000c9292610000, 0x00000c12a2410000, 0x0000003cc2010000,
        0x000000c33c000000, 0x0000804324180000, 0x0000c32424180000};

    const uint8_t *charToLedLetter(char c)
    {
        switch (c)
        {
        case 'G':
            return LETTER_G;
        case 'A':
            return LETTER_A;
        case 'M':
            return LETTER_M;
        case 'E':
            return LETTER_E;
        case 'O':
            return LETTER_O;
        case 'V':
            return LETTER_V;
        case 'R':
            return LETTER_R;
        case 'P':
            return LETTER_P;
        case 'L':
            return LETTER_L;
        case 'Y':
            return LETTER_Y;
        default:
            return LETTER_EMPTY;
        }
    }

    void drawFrame(uint64_t frame)
    {
        for (int m = 0; m < numModules; m++)
        {
            for (int r = 0; r < MATRIX_SIZE; r++)
            {
                byte rowData = (frame >> (r * 8)) & 0xFF;
                lc.setRow(m, r, rowData);
            }
        }
    }

public:
    Display(LedControl &lc, int numModules, int screenWidth)
        : lc(lc), numModules(numModules) {}

    void setup()
    {
        for (int i = 0; i < numModules; i++)
        {
            lc.shutdown(i, false);
            lc.setIntensity(i, 5);
            lc.clearDisplay(i);
        }
    }

    void clearDisplay()
    {
        for (int i = 0; i < numModules; i++)
        {
            lc.clearDisplay(i);
        }
    }

    void rotateMatrixSymbol(const uint8_t *letter, uint8_t *rotatedLetter)
    {
        memset(rotatedLetter, 0, MATRIX_SIZE);
        for (int y = 0; y < MATRIX_SIZE; y++)
        {
            uint8_t row = pgm_read_byte(&(letter[y]));
            for (int x = 0; x < MATRIX_SIZE; x++)
            {
                if (bitRead(row, x))
                {
                    int newX = 7 - y;
                    int newY = x;
                    bitSet(rotatedLetter[newY], newX);
                }
            }
        }
    }

    void PrintText(const char *text)
    {
        for (int m = 0; m < numModules; m++)
        {
            if (text[m] == '\0')
                break;

            const uint8_t *letterPtr = charToLedLetter(text[m]);
            uint8_t rotatedLetter[MATRIX_SIZE];

            rotateMatrixSymbol(letterPtr, rotatedLetter);

            int moduleIndex = numModules - 1 - m;

            for (int row = 0; row < MATRIX_SIZE; row++)
            {
                lc.setRow(moduleIndex, row, rotatedLetter[row]);
            }
        }
    }

    void gameOverAnimation()
    {
        for (int i = 0; i < 200; i++)
        {
            int m = random(numModules);
            int r = random(8);
            int c = random(8);
            lc.setLed(m, r, c, true);
            if (i % 5 == 0)
                delay(2); 
        }

        for (int m = 0; m < numModules; m++)
        {
            for (int r = 0; r < 8; r++)
                lc.setRow(m, r, 0xFF);
        }
        delay(150);
        clearDisplay();
        delay(100);

        for (int r = 0; r < 8; r++)
        {
            for (int m = 0; m < numModules; m++)
            {
                lc.setRow(m, r, 0xFF);
                if (r > 0)
                    lc.setRow(m, r - 1, 0x00);
            }
            delay(80);
        }
        clearDisplay();
        delay(500);

        const char *messages[] = {"GAME", "OVER"};
        for (int i = 0; i < 2; i++)
        {
            PrintText(messages[i]);

            for (int s = 0; s < 4; s++)
            {
                delay(200);
                for (int m = 0; m < numModules; m++)
                    lc.setIntensity(m, 8);
                delay(50);
                for (int m = 0; m < numModules; m++)
                    lc.setIntensity(m, 3);
            }

            clearDisplay();
        }
    }
};