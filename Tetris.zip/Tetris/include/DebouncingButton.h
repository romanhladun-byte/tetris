#pragma once
#include <Arduino.h>

class DebButton
{
private:
    int pin;      
    bool lastState;             
    unsigned long lastDebounceTime;  
    const unsigned long debounceDelay = 100;    

public:
    DebButton(int pin) : pin(pin)
    {
        lastState = HIGH; 
        lastDebounceTime = 0;
    }

    void attach()
    {
        pinMode(pin, INPUT_PULLUP);
    }

    bool isClicked()
    {
        int reading = digitalRead(pin);

        if (reading != lastState)
        {
            lastDebounceTime = millis();
        }

        if ((millis() - lastDebounceTime) > debounceDelay && reading == HIGH)
        {
            lastDebounceTime = millis();
            return true;
        }
        
        if (reading == LOW && lastState == HIGH && (millis() - lastDebounceTime > debounceDelay)) 
        {
            lastDebounceTime = millis();
            lastState = LOW; 
            return true;     
        }

        if (reading == HIGH)
        {
            lastState = HIGH; 
        }

        return false;
    }
    
    
    void waitForButtonPress()
    {        
        while (digitalRead(pin) == HIGH) {
            delay(10);
        }
        
        while (digitalRead(pin) == LOW) {
            delay(10);
        }
    }
    
    void update() {
    }
};