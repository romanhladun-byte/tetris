#pragma once
#include <Arduino.h>
#include "Tetramino.h"
#include "Sounds.h"

class LedControl; 

/**
 * @brief Клас, що керує ігровим полем та логікою взаємодії об'єктів
 */
class Field
{
private:
    static constexpr int WIDTH = 8;
    static constexpr int HEIGHT = 32;
    static constexpr int MODULES = 4;
    static constexpr int PIXELS_PER_FIGURE = 4;

    uint8_t _grid[HEIGHT]; 
    Buzzer _buzzer;

public:
    Field();
    
    ~Field() = default;

    int getWidth() const { return WIDTH; }
    int getHeight() const { return HEIGHT; }
    int getModules() const { return MODULES; }
    int getPixelsPerPiece() const { return PIXELS_PER_FIGURE; }

    const uint8_t* getGrid() const { return _grid; }
    uint8_t* getGrid() { return _grid; }

    void checkForFullRows();

    void addPieceToField(const Block &block);

    bool checkCollision(const Block &block, int newX, int newY) const;

    bool isCollisionAtTop(const Block &block, int newX, int newY) const;

    void placeBlock(Block &block);
    
    bool dropPiece(Block &block);

    void writeBuffer(const Block &block, LedControl &lc);
};