#pragma once
#include "TetraminoShapes.h"
#include <Arduino.h>

class Field; 

class Block {
public:
    enum class Type : char {
        None = ' ',
        I = 'I', O = 'O', T = 'T', 
        L = 'L', J = 'J', S = 'S', Z = 'Z'
    };

private:
    const int (*_shape)[2] = nullptr; 
    int _x = 0;
    int _y = 0;              
    int _rotation = 0;          
    Type _type = Type::None;             

public:
    Block() = default;

    Block(const int (*shape)[2], int x, int y, int rotation, Type type)
        : _shape(shape), _x(x), _y(y), _rotation(rotation), _type(type) {}

    int getX() const { return _x; }
    int getY() const { return _y; }
    int getRotation() const { return _rotation; }
    Type getType() const { return _type; }
    const int (*getShape() const)[2] { return _shape; }
    
    bool hasShape() const { return _shape != nullptr; }

    void setX(int x) { _x = x; }
    void setY(int y) { _y = y; }
    void setRotation(int rotation) { _rotation = rotation; }
    void setType(Type type) { _type = type; }
    void setShape(const int (*shape)[2]) { _shape = shape; }

    void chose(int r, int startX);
    
    void spawnBlock(Field &field);
   
    void rotatePiece(Field &field);
    
    void movePiece(int dir, Field &field); 
};